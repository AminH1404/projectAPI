import React from 'react';

function NewsItem({ item }) {
  return (
    <div className="article">
      <div className="article-image">
        <img src={item.urlToImage} alt={item.title} />
      </div>
      <div className="article-content">
        <h2>{item.title}</h2>
        <p>{item.description}</p>
        <div className="article-source">
          <span>{item.source.name}</span>
          <a href={item.url} target="_blank" rel="noopener noreferrer">
            Read More
          </a>
        </div>
      </div>
    </div>
  );
}

export default NewsItem;

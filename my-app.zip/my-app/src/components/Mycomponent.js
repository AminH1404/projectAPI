// Example: src/components/MyComponent.js
import React from 'react';
import { useMyContext } from '../contexts/MyContext';

const MyComponent = () => {
  const { state, setState } = useMyContext();
  // use state and setState here
  return <div>{state.someProperty}</div>;
};

export default MyComponent;
